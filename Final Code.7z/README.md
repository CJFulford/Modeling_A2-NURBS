# Modeling_A2-NURBS

Author: Cody Fulford

This code is written for the second assignment of CPSC 589 - Modeling at the University of Calgary, Winter 2017

This code uses GLFW x32, GLAD V4.5, and GLM
This code was created for use with OpenGL V4.5

Program to draw and edit NURBS curves

The basic code for this project has been converted from assignment 1 from the same course.
The beginnings of the b-spline code has been taken from my assignment 1 for CPSC 587 - Animation at the University of Calgary, Winter 2017.
